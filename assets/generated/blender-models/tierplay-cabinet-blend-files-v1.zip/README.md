# Tierplay cabinet Blender files

## Deliverables

- `tierplay-altitude-cabinet-v1.blend`
- `tierplay-pinnacle-cabinet-v1.blend`
- `tierplay-cabinet-blend-files-v1.zip`

The `.blend` files are self-contained and have their image textures packed. They were generated and validated headlessly with Blender 4.5.11 LTS.

## Included setup

- Metric scene units
- Separately named cabinet parts
- Beveled visualization geometry
- Black powder-coated metal, satin plastic, brushed metal and rubber materials
- Emissive violet and cyan trim
- Curved display geometry for Pinnacle
- Flat portrait display geometry for Altitude
- Packed game-screen textures
- Packed official Tierplay logo texture on a dedicated UV badge plane
- Key, fill and rim studio lights
- Ground plane and backdrop
- Front, three-quarter hero, side and rear cameras
- Eevee render configuration

## Validation

- Altitude: 53 objects, 12 materials, 4 cameras
- Pinnacle: 52 objects, 12 materials, 4 cameras
- Both files reopened successfully in a separate headless Blender process.
- All file-backed textures reported as packed.
- Front, three-quarter and rear preview renders completed successfully.

## Accuracy boundary

These are production-visualization models, not manufacturing CAD. The visible silhouette and control layout are based on the recovered front-view references and the generated turnaround boards. Cabinet depth, rear panels, vents, service access and fastener placement are conservative concept geometry because manufacturer CAD, measured elevations and rear photography were not available.

Do not use these files for fabrication, compliance, thermal engineering or dimensional claims without approved manufacturer data.

## Rebuilding headlessly

`build_tierplay_cabinets.py` reconstructs either file using the packed-source textures in `textures/`. Set `TIERPLAY_MODEL=Altitude` or `TIERPLAY_MODEL=Pinnacle` before running it through Blender in background mode.
